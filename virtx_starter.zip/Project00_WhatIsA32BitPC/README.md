# Project00_WhatIsA32BitPC

WIP: To be filled with code and notes.