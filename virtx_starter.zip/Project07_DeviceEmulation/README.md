# Project07_DeviceEmulation

WIP: To be filled with code and notes.