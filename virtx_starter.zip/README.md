# VirtX

A guided project series on building a hypervisor and a simple OS.
