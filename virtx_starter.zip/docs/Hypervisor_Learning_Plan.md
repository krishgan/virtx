See https://chat.openai.com/c/virtx for the project plan.
